package com.mycompany.studentgraduate;

public class Student {
    private String studentName;
    private String studentSurname;
    private String studentNumber;
    private int numberSubjects;
    private boolean isGraduate;

    //Constructor parameters
    public Student(String studentName, String studentSurname, String studentNumber, int numberSubjects) {
        this.studentName = studentName;
        this.studentSurname = studentSurname;
        this.studentNumber = studentNumber;
        this.numberSubjects = numberSubjects;
    }

    //Get
    public String getStudentName() {
        return studentName;
    }

    public String getStudentSurname() {
        return studentSurname;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public int getNumberSubjects() {
        return numberSubjects;
    }

    public boolean getIsGraduate() {
        return isGraduate;
    }

    //Set
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentSurname(String studentSurname) {
        this.studentSurname = studentSurname;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public void setNumberSubjects(int numberSubjects) {
        this.numberSubjects = numberSubjects;
    }

    public void setIsGraduate(boolean isGraduate) {
        this.isGraduate = isGraduate;
    }

    //Check
    public boolean checkGraduate() {
        isGraduate = numberSubjects == 35;
        return isGraduate;
    }
}

