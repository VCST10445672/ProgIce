package com.mycompany.studentgraduate;

import javax.swing.JOptionPane;

public class StudentGraduate {
    public static void main(String[] args) {
        String name = JOptionPane.showInputDialog("Enter student name:");
        String surname = JOptionPane.showInputDialog("Enter student surname:");
        String studentNumber = JOptionPane.showInputDialog("Enter student number (digits only):");

        int confirm = JOptionPane.showConfirmDialog(null, "Did the student start after 2010?", "Student Year Check", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION && !studentNumber.startsWith("S")) {
            studentNumber = "S" + studentNumber;
        }

        int numSubjects = Integer.parseInt(JOptionPane.showInputDialog("Enter number of subjects completed:"));

        //Student obj constructor
        Student stud = new Student(name, surname, studentNumber, numSubjects);
        boolean graduated = stud.checkGraduate();

        String message = "Student Details:\n";
        message += "Name: " + stud.getStudentName() + "\n";
        message += "Surname: " + stud.getStudentSurname() + "\n";
        message += "Student Number: " + stud.getStudentNumber() + "\n";
        message += "Subjects Completed: " + stud.getNumberSubjects() + "\n";
        message += "Graduate Status: " + (graduated ? "✅ Graduate" : "❌ Not a Graduate");

        JOptionPane.showMessageDialog(null, message);
    }
}

