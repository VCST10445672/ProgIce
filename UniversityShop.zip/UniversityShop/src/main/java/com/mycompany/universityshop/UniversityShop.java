package com.mycompany.universityshop;

import javax.swing.*;

public class UniversityShop {
    public static void main(String[] args) {
        String name = JOptionPane.showInputDialog("Enter student name:");
        String surname = JOptionPane.showInputDialog("Enter student surname:");
        String number = JOptionPane.showInputDialog("Enter student number:");

        int isAlumniOption = JOptionPane.showConfirmDialog(null, "Is the student an Alumni?", "Alumni Status", JOptionPane.YES_NO_OPTION);
        boolean isAlumni = (isAlumniOption == JOptionPane.YES_OPTION);

        Sales sale = new Sales(number, name, surname, isAlumni);
        sale.displayMenu();
    }
}

