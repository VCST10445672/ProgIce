/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ice6;

import java.util.Scanner;

public class ICE6 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String[] studentNumbers = new String[3];
        double[] finalMarks = new double[3];
        String[] results = new String[3];

        for (int i = 0; i < 3; i++) {
            System.out.println("Enter student number for Student " + (i + 1) + ":");
            studentNumbers[i] = input.nextLine();

            double iceTotal = 0;
            for (int j = 1; j <= 4; j++) {
                System.out.println("Enter mark for ICE Task " + j + " (out of 100):");
                double mark = input.nextDouble();
                iceTotal += mark;
            }

            double iceAverage = iceTotal / 4;
            double iceWeight = iceAverage * 0.25;

            System.out.println("Enter Part 1 mark (out of 100):");
            double part1 = input.nextDouble() * 0.30;

            System.out.println("Enter Part 2 mark (out of 100):");
            double part2 = input.nextDouble() * 0.30;

            System.out.println("Enter attendance percentage:");
            int attendance = input.nextInt();
            input.nextLine(); // consume newline

            double attendanceMark = 0;
            if (attendance < 50) {
                attendanceMark = 5;
            } else if (attendance <= 74) {
                attendanceMark = 10;
            } else {
                attendanceMark = 15;
            }

            finalMarks[i] = Math.round((iceWeight + part1 + part2 + attendanceMark));
            if (finalMarks[i] >= 75) {
                results[i] = "Pass with Distinction";
            } else if (finalMarks[i] >= 50) {
                results[i] = "Pass";
            } else {
                results[i] = "Fail";
            }
        }

        // Display results
        System.out.println("\nPROG Results");
        System.out.printf("%-12s %-10s %-20s\n", "stNumber", "stMark", "stResults");
        for (int i = 0; i < 3; i++) {
            System.out.printf("%-12s %-10s %-20s\n", studentNumbers[i], (int)finalMarks[i] + "%", results[i]);
        }

        input.close();
    }
}
