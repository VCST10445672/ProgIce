package com.mycompany.universityshop;

import javax.swing.*;

public class Sales {
    private double studentBalance;
    private Student studentDetails;

    public Sales(String studentNumber, String studentName, String studentSurname, boolean isAlumni) {
        studentDetails = new Student(studentNumber, studentName, studentSurname);
        studentBalance = isAlumni ? 3500.0 : 5000.0;
    }

    public void displayMenu() {
        int option;
        do {
            option = Integer.parseInt(JOptionPane.showInputDialog("""
                Select Option:
                1. Make a Purchase
                2. Recharge the Account
                3. Exit"""));

            switch (option) {
                case 1 -> purchaseItem();
                case 2 -> rechargeAmount();
                case 3 -> JOptionPane.showMessageDialog(null, "Thank you! Goodbye.");
                default -> JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
            }
        } while (option != 3);
    }

    private void purchaseItem() {
        String menu = """
                Items to buy:
                1. Cap - R150.00
                2. T-shirt - R200.00
                3. Laptop - R4500.00
                4. Jersey - R600.00
                5. Bottle - R25.00
                6. Jacket - R750.00
                7. Power Bank - R450.00""";

        int item = Integer.parseInt(JOptionPane.showInputDialog(menu));
        double cost = 0.0;

        switch (item) {
            case 1 -> cost = 150;
            case 2 -> cost = 200;
            case 3 -> cost = 4500;
            case 4 -> cost = 600;
            case 5 -> cost = 25;
            case 6 -> cost = 750;
            case 7 -> cost = 450;
            default -> {
                JOptionPane.showMessageDialog(null, "Invalid item selected.");
                return;
            }
        }

        if (cost > studentBalance) {
            JOptionPane.showMessageDialog(null, "Insufficient balance.");
        } else {
            studentBalance -= cost;
            JOptionPane.showMessageDialog(null, "Purchase successful!\nNew Balance: R" + studentBalance);
        }
    }

    private void rechargeAmount() {
        double recharge = Double.parseDouble(JOptionPane.showInputDialog("Enter amount to recharge: "));
        studentBalance += recharge;
        JOptionPane.showMessageDialog(null, "Recharge successful!\nNew Balance: R" + studentBalance);
    }
}

