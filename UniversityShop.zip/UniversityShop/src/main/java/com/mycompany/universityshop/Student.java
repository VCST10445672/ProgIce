package com.mycompany.universityshop;

public class Student {
    private String studentName;
    private String studentSurname;
    private String studentNumber;

    public Student(String studentNumber, String studentName, String studentSurname) {
        this.studentName = studentName;
        this.studentSurname = studentSurname;
        this.studentNumber = studentNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getStudentSurname() {
        return studentSurname;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentSurname(String studentSurname) {
        this.studentSurname = studentSurname;
    }

    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }

    public String toString() {
        return "Student: " + studentName + " " + studentSurname + "\nStudent Number: " + studentNumber;
    }
}
